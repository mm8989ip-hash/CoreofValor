package com.coreofvalor;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class CoreOfValor extends JavaPlugin {
    private AbilityManager abilityManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        FileConfiguration cfg = getConfig();

        this.abilityManager = new AbilityManager(this);
        getCommand("core").setExecutor(new CoreCommand(this));

        Bukkit.getLogger().info("CoreOfValor enabled. Default core color: " + cfg.getString("core.default_color"));
    }

    @Override
    public void onDisable() {
        Bukkit.getLogger().info("CoreOfValor disabled.");
    }

    public AbilityManager getAbilityManager() {
        return abilityManager;
    }
}
