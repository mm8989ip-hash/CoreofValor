package com.coreofvalor;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CoreCommand implements CommandExecutor {
    private final CoreOfValor plugin;

    public CoreCommand(CoreOfValor plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players may use this command.");
            return true;
        }

        Player p = (Player) sender;
        if (args.length == 0) {
            p.sendMessage(ChatColor.YELLOW + "CoreOfValor: /core select <name> | /core use");
            return true;
        }

        if (args[0].equalsIgnoreCase("select") && args.length >= 2) {
            String coreName = args[1].toLowerCase();
            boolean ok = plugin.getAbilityManager().selectCore(p, coreName);
            if (ok) {
                p.sendMessage(ChatColor.GREEN + "Selected core: " + coreName);
            } else {
                p.sendMessage(ChatColor.RED + "Core not found: " + coreName);
            }
            return true;
        }

        if (args[0].equalsIgnoreCase("use")) {
            plugin.getAbilityManager().useCore(p);
            return true;
        }

        p.sendMessage(ChatColor.YELLOW + "CoreOfValor: /core select <name> | /core use");
        return true;
    }
}
