package com.coreofvalor;

public class CoreAbility {
    private final String id;
    private final String display;
    private final int cooldown;
    private final String color;

    public CoreAbility(String id, String display, int cooldown, String color) {
        this.id = id;
        this.display = display;
        this.cooldown = cooldown;
        this.color = color;
    }

    public String getId() { return id; }
    public String getDisplay() { return display; }
    public int getCooldown() { return cooldown; }
    public String getColor() { return color; }
}
