package com.coreofvalor;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class AbilityManager {
    private final CoreOfValor plugin;
    private final Map<Player, CoreAbility> selected = new HashMap<>();
    private final Map<String, CoreAbility> registry = new HashMap<>();

    public AbilityManager(CoreOfValor plugin) {
        this.plugin = plugin;
        loadDefaults();
    }

    private void loadDefaults() {
        FileConfiguration cfg = plugin.getConfig();
        // Default abilities configured in config.yml
        if (cfg.isConfigurationSection("abilities")) {
            for (String key : cfg.getConfigurationSection("abilities").getKeys(false)) {
                String display = cfg.getString("abilities." + key + ".display", key);
                int cooldown = cfg.getInt("abilities." + key + ".cooldown", 10);
                String color = cfg.getString("core.default_color", "yellow");
                registry.put(key.toLowerCase(), new CoreAbility(key.toLowerCase(), display, cooldown, color));
            }
        }
    }

    public boolean selectCore(Player p, String coreName) {
        CoreAbility ability = registry.get(coreName.toLowerCase());
        if (ability == null) return false;
        selected.put(p, ability);
        p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&eSelected core: &f" + ability.getDisplay()));
        return true;
    }

    public void useCore(Player p) {
        CoreAbility ability = selected.get(p);
        if (ability == null) {
            p.sendMessage(ChatColor.RED + "No core selected. Use /core select <name>");
            return;
        }
        // Placeholder effect: sound + chat
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
        p.sendMessage(ChatColor.YELLOW + "Used core: " + ability.getDisplay());
        // You can extend with real ability effects here (entity scans, buffs, projectiles, etc.)
    }
}
